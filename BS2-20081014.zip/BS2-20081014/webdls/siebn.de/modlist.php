IF ((BSVERSION < 1901100) && (versioncheck == 0)) {
	versioncheck = 1
	MESSAGE CLEAR
	MESSAGE ADDTEXT "You've got an old version of BS2."
	MESSAGE ADDLINE
	MESSAGE ADDTEXT "Go to http://siebn.de and download the newest version."
	MESSAGE MESSAGEBOX
}
MENU SUB CLEAR
IF (BUTTON == 1) {
}
IF (BUTTON == 2) {
  MENU SUB ADD TEST "A-M" TEXT "A-M" {
    MENU SUB CLEAR
    SUBMENU
  } 
  
  MENU SUB ADD TEST "N-Z" TEXT "N-Z" {
    MENU SUB CLEAR
    SUBMENU
  }
} 
IF (BUTTON == 4) {
}
SUBMENU
